#Luke Rohweder
#CTI 110
#12-3-22
#This is my final project. A series of games that we created in class, and some that I created myself. I did need help with the tic tac toe game, and it was fun learning and teaching myself something outside of class. Thanks for being a great teacher Mr. Norris. Hopefully I'll be able to get into your C++ class next semester!

import random

def guess_the_number():
    print("I'm thinking of a number between 1 and 100")
    number = random.randint(1, 100)
  
    for tries in range (6):
        guess = int(input("What's your guess? "))
        if guess > number:
            print("Too high!")
        elif guess < number:
            print("Too low!")
    else:
        if guess == number:
            print("Congratulations, you guessed my number!")
  
        else:
            print("Too bad, so sad")
      
def tic_tac_toe():
  print("This is a 2 player game, if you want to place a marker down, simply put the number of column and the number of row you want to place the marker down. For example: If I want to place the marker down in the top left spot, I would say 1 1. If I want to place it down in the bottom right spot, I would say 3 3. Make sure to add a space between both numbers!")
  class TicTacToe:
    def __init__(self):
        self.board = []

    def create_board(self):
        for i in range(3):
            row = []
            for j in range(3):
                row.append('-')
            self.board.append(row)

    def get_random_first_player(self):
        return random.randint(0, 1)

    def fix_spot(self, row, col, player):
        self.board[row][col] = player

    def is_player_win(self, player):
        win = None
        n = len(self.board)
        for i in range(n):
            win = True
            for j in range(n):
                if self.board[i][j] != player:
                    win = False
                    break
            if win:
                return win
        for i in range(n):
            win = True
            for j in range(n):
                if self.board[j][i] != player:
                    win = False
                    break
            if win:
                return win

        win = True
        for i in range(n):
            if self.board[i][i] != player:
                win = False
                break
        if win:
            return win

        win = True
        for i in range(n):
            if self.board[i][n - 1 - i] != player:
                win = False
                break
        if win:
            return win
        return False

        for row in self.board:
            for item in row:
                if item == '-':
                    return False
        return True

    def is_board_filled(self):
        for row in self.board:
            for item in row:
                if item == '-':
                    return False
        return True

    def swap_player_turn(self, player):
        return 'X' if player == 'O' else 'O'

    def show_board(self):
        for row in self.board:
            for item in row:
                print(item, end=" ")
            print()

    def start(self):
        self.create_board()

        player = 'X' if self.get_random_first_player() == 1 else 'O'
        while True:
            print(f"Player {player} turn")

            self.show_board()
            
            row, col = list(
                map(int, input("Enter row and column numbers to fix spot: ").split()))
            print()

            self.fix_spot(row - 1, col - 1, player)

            if self.is_player_win(player):
                print(f"Player {player} wins the game!")
                break

            if self.is_board_filled():
                print("Match Draw!")
                break
              
            player = self.swap_player_turn(player)

        print()
        self.show_board()
        
  tic_tac_toe = TicTacToe()
  tic_tac_toe.start()
  
def rock_paper_scissors():
  user_action = input("Enter a choice (rock, paper, scissors): ")
  possible_actions = ["rock", "paper", "scissors"]
  computer_action = random.choice(possible_actions)
  print(f"\nYou chose {user_action}, computer chose {computer_action}.\n")

  if user_action == computer_action:
    print(f"Both players selected {user_action}. It's a tie!")
  elif user_action == "rock":
    if computer_action == "scissors":
        print("Rock smashes scissors! You win!")
    else:
        print("Paper covers rock! You lose.")
  elif user_action == "paper":
    if computer_action == "rock":
        print("Paper covers rock! You win!")
    else:
        print("Scissors cuts paper! You lose.")
  elif user_action == "scissors":
    if computer_action == "paper":
        print("Scissors cuts paper! You win!")
    else:
        print("Rock smashes scissors! You lose.")

def mad_libs():
  adjective = input("Enter an adjective: ")
  adjective2 = input("Enter an adjective: ")
  bird = input("Enter a type of bird: ")
  room = input("Enter a room in the house: ")
  verbPast = input("Enter a past tense verb: ")
  verb2 = input("Enter a verb: ")
  relative = input("Enter a relative's name: ")
  noun = input("Enter a noun: ")
  liquid = input("Enter a liquid: ")
  verbing = input("Enter a verb ending with -ing: ")
  bodyPart = input("Enter a body part: ")
  pluralNoun = input("Enter a plural noun: ")
  verbing2 = input("Enter a verb that ends with -ing: ")
  noun2 = input("Enter a noun: ")
  
  
  print("It was a ", adjective, " cold November day.")
  print("I woke up to the ", adjective2, " smell of", bird, "roasting in the ", room, "downstairs.")
  print("I ", verbPast, " down the stairs to see if I could help ", verb2," the dinner.")
  print("My mom said See if ", relative, " needs a fresh ", noun, ".")
  print("So I carried a tray of glasses full of ", liquid, "into the ", verbing, " room." )
  print("When I got there, I couldnt believe my ", bodyPart, "!")
  print("There were", pluralNoun, verbing2, "on the ", noun2, "!")

def magic_8_ball():
  print("What would you like to know?")

  answer = input("")

  random_number = random.randint(1, 9)

  if random_number == 1:
    answer = "Yes - definitely"

  elif random_number == 2:
    answer = "It is decidedly so"

  elif random_number == 3:
    answer = "Without a doubt"

  elif random_number == 4:
    answer = "Reply hazy, try again"

  elif random_number == 5:
    answer = "I will not tell you"

  elif random_number == 6:
    answer = "My sources say no, sorry"

  elif random_number == 7:
    answer = "Outlook not so good"
  
  elif random_number == 8:
    answer = "Very doubtful"
  
  elif random_number == 9:
    answer = "You're a grown person asking if a computer generated program can answer your question...what do you think?"

  print("Magic 8-Ball says:", answer)

def main():
  guess_the_number()
  tic_tac_toe()
  mad_libs()
  rock_paper_scissors()
  magic_8_ball()
keepGoing = True
while keepGoing:
    print("Welcome to the Luke's Final Project Game Menu")
    print("-"*45)
    print("1. Guess the number")
    print("2. Tic Tac Toe")
    print("3. Rock, Paper, Scissors")
    print("4. Mad Libs")
    print("5. Magic 8 Ball")
    choice = int(input())
    if choice == 1:
      guess_the_number()
    elif choice == 2:
      tic_tac_toe()
    elif choice == 3:
      rock_paper_scissors()
    elif choice == 4:
      mad_libs()
    elif choice == 5:
      magic_8_ball()
    else:
      print("Please choose 1, 2, 3, 4, or 5.")

main()